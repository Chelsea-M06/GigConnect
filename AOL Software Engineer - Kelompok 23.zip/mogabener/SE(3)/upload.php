<?php
$desc = $_POST['desc'];
//echo "$desc"
// if($_SERVER["REQUEST_METHOD"] === "POST"){
//         $uploadedFile = $_FILES['file'];
     
//         // Process the uploaded file
//         // ...
//      }

header("Location: Register31.html")
?>