<?php 
          $firstName = $_SESSION['firstName'];
          $lastName = $_SESSION['lastName'];
          echo "$firstName $lastName";
          ?>